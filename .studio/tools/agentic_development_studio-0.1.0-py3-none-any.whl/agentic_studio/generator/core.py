from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

import yaml

from agentic_studio.adapters.codex import CodexNativeMapping
from agentic_studio.control.governance import CanonicalAssetLoader


class GenerationError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class GenerationResult:
    destination: Path
    runtime: str
    files: tuple[str, ...]


class ProjectGenerator:
    _project_id = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
    _project_name = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._-]{0,119}$")
    _token = re.compile(r"\{\{[A-Z][A-Z0-9_]*\}\}")
    _text_suffixes = frozenset({"", ".md", ".toml", ".yaml", ".yml", ".json", ".txt"})

    def __init__(self, source_root: Path) -> None:
        self.source_root = source_root.resolve()
        manifest_path = self.source_root / "shared" / "export-manifest.yaml"
        self.manifest: dict[str, Any] = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))

    def generate(
        self,
        project_id: str,
        project_name: str,
        destination: Path,
        runtime: str = "codex",
        *,
        git_init: bool = False,
    ) -> GenerationResult:
        if not self._project_id.fullmatch(project_id):
            raise GenerationError("project ID must be a stable lowercase identifier")
        if not self._project_name.fullmatch(project_name):
            raise GenerationError("project name contains unsafe template characters")
        overlays = self.manifest["runtime_overlays"]
        locks = self.manifest["runtime_locks"]
        if runtime != "codex" or runtime not in overlays or runtime not in locks:
            raise GenerationError("runtime is not available in Stage One")
        destination = destination.resolve()
        if destination.exists():
            raise FileExistsError(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        staging = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent))
        substitutions = {"PROJECT_ID": project_id, "PROJECT_NAME": project_name}
        try:
            self._copy_tree(
                self._source_path(self.manifest["base_template_path"]),
                staging,
                substitutions,
            )
            for relative in self.manifest["shared_paths"]:
                source = self._source_path(relative)
                self._copy_tree(source, staging / relative, substitutions)
            guide = self.manifest["project_guide_path"]
            self._copy_tree(self._source_path(guide), staging / guide, substitutions)
            self._copy_tree(
                self._source_path(overlays[runtime]),
                staging,
                substitutions,
            )
            self._copy_file(
                self._source_path(locks[runtime]),
                staging / f"studio-{runtime}.uv.lock",
                substitutions,
            )
            tools = staging / ".studio" / "tools"
            wheel_source = self._source_path(self.manifest["tool_wheel_path"])
            lock_source = self._source_path(locks[runtime])
            bootstrap_source = self._source_path(self.manifest["bootstrap_path"])
            self._copy_file(
                wheel_source,
                tools / wheel_source.name,
                substitutions,
            )
            self._copy_file(
                lock_source,
                tools / f"studio-{runtime}.uv.lock",
                substitutions,
            )
            self._copy_file(
                bootstrap_source,
                tools / "bootstrap.py",
                substitutions,
            )
            tool_manifest = {
                "schema_version": "1.0.0",
                "studio_version": "0.1.0",
                "python": "==3.12.*",
                "uv_minimum": "0.12.0",
                "wheel": {
                    "file": wheel_source.name,
                    "sha256": hashlib.sha256(wheel_source.read_bytes()).hexdigest(),
                },
                "lock": {
                    "file": f"studio-{runtime}.uv.lock",
                    "sha256": hashlib.sha256(lock_source.read_bytes()).hexdigest(),
                },
            }
            (tools / "tool-manifest.json").write_text(
                json.dumps(tool_manifest, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            canonical_assets = CanonicalAssetLoader().load_tree(staging / "shared")
            CodexNativeMapping(staging).write_role_files(
                canonical_assets.role_catalog,
                canonical_assets.capability_registry,
            )
            for relative in ("runs", "context", "security"):
                (staging / ".studio" / relative).mkdir(parents=True, exist_ok=True)
            self._assert_no_unresolved_tokens(staging)
            if git_init:
                subprocess.run(
                    ["git", "init", "--quiet"],
                    cwd=staging,
                    check=True,
                    capture_output=True,
                    text=True,
                )
            os.replace(staging, destination)
        except Exception:
            shutil.rmtree(staging, ignore_errors=True)
            raise
        files = tuple(
            sorted(
                path.relative_to(destination).as_posix()
                for path in destination.rglob("*")
                if path.is_file()
            )
        )
        return GenerationResult(destination, runtime, files)

    def _source_path(self, relative: str) -> Path:
        if (
            not relative
            or "\\" in relative
            or PurePosixPath(relative).is_absolute()
            or ".." in PurePosixPath(relative).parts
        ):
            raise GenerationError("export manifest path must be repository-relative")
        candidate = self.source_root / relative
        if (
            not candidate.exists()
            and relative == self.manifest.get("bootstrap_path")
            and self.source_root.name == "_assets"
        ):
            candidate = Path(__file__).resolve().parents[1] / "bootstrap.py"
            if not candidate.is_file():
                raise GenerationError("packaged bootstrap helper is missing")
            return candidate
        resolved = candidate.resolve()
        if not resolved.is_relative_to(self.source_root):
            raise GenerationError("export manifest path escapes the source root")
        return resolved

    def _copy_tree(self, source: Path, destination: Path, substitutions: dict[str, str]) -> None:
        if source.is_symlink() or not source.is_dir():
            raise GenerationError(f"manifest source is not a safe directory: {source}")
        for path in sorted(source.rglob("*")):
            relative = path.relative_to(source)
            if path.is_symlink():
                raise GenerationError(f"manifest source contains a symbolic link: {relative}")
            if path.is_dir():
                continue
            self._copy_file(path, destination / relative, substitutions)

    def _copy_file(self, source: Path, destination: Path, substitutions: dict[str, str]) -> None:
        if destination.exists():
            raise GenerationError(f"manifest paths collide at {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        if source.suffix.lower() in self._text_suffixes:
            content = source.read_text(encoding="utf-8")
            for name, value in substitutions.items():
                content = content.replace(f"{{{{{name}}}}}", value)
            destination.write_text(content, encoding="utf-8")
        else:
            shutil.copyfile(source, destination)
        shutil.copymode(source, destination)

    def _assert_no_unresolved_tokens(self, root: Path) -> None:
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in self._text_suffixes:
                continue
            if self._token.search(path.read_text(encoding="utf-8")):
                raise GenerationError(f"unresolved template variable in {path.relative_to(root)}")
