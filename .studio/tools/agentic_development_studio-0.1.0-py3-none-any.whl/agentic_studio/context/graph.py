from __future__ import annotations

import ast
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import PurePosixPath
from types import MappingProxyType

from agentic_studio.contracts import BlastRadius

from .index import IndexSnapshot


@dataclass(frozen=True, slots=True)
class GraphImpact:
    affected_code: tuple[str, ...]
    affected_tests: tuple[str, ...]
    confidence: str
    unknown_edges: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class StructuralGraph:
    dependencies: Mapping[str, frozenset[str]]
    unknown_edges: tuple[str, ...]

    @classmethod
    def from_index(cls, snapshot: IndexSnapshot) -> StructuralGraph:
        known_paths = {record.path for record in snapshot.records}
        dependencies: dict[str, frozenset[str]] = {}
        unknowns: list[str] = []
        for record in snapshot.records:
            if record.language != "python":
                dependencies[record.path] = frozenset()
                continue
            try:
                tree = ast.parse(record.content, filename=record.path)
            except SyntaxError:
                unknowns.append(f"syntax:{record.path}")
                dependencies[record.path] = frozenset()
                continue
            imported: set[str] = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imported.update(_module_path(alias.name) for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imported.add(_module_path(node.module))
                elif isinstance(node, ast.Call) and _dynamic_call(node):
                    unknowns.append(f"dynamic:{record.path}:{node.lineno}")
            dependencies[record.path] = frozenset(path for path in imported if path in known_paths)
        return cls(MappingProxyType(dependencies), tuple(sorted(set(unknowns))))

    def reverse_impact(self, changed_paths: list[str]) -> GraphImpact:
        affected = set(changed_paths)
        pending = list(changed_paths)
        while pending:
            current = pending.pop()
            for importer, imports in self.dependencies.items():
                if current in imports and importer not in affected:
                    affected.add(importer)
                    pending.append(importer)
        tests = tuple(sorted(path for path in affected if _is_test(path)))
        code = tuple(sorted(path for path in affected if not _is_test(path)))
        return GraphImpact(
            code,
            tests,
            "medium" if self.unknown_edges else "high",
            self.unknown_edges,
        )

    def blast_radius(self, changed_paths: list[str], graph_snapshot_id: str) -> BlastRadius:
        impact = self.reverse_impact(changed_paths)
        return BlastRadius(
            schema_version="1.0.0",
            blast_radius_id=f"radius-{graph_snapshot_id[:16]}",
            graph_snapshot_id=graph_snapshot_id,
            graph_fresh=True,
            affected_code=list(impact.affected_code),
            affected_contracts=[],
            affected_tests=list(impact.affected_tests),
            affected_owners=[],
            affected_build_paths=[],
            confidence=impact.confidence,
            unknown_edges=list(impact.unknown_edges),
            verification_plan=[
                f"verify {path}" for path in (*impact.affected_code, *impact.affected_tests)
            ],
        )


def _module_path(module: str) -> str:
    return PurePosixPath(*module.split(".")).as_posix() + ".py"


def _dynamic_call(node: ast.Call) -> bool:
    if isinstance(node.func, ast.Name):
        return node.func.id in {"getattr", "setattr", "__import__"}
    if isinstance(node.func, ast.Attribute):
        return node.func.attr == "import_module"
    return False


def _is_test(path: str) -> bool:
    name = PurePosixPath(path).name
    return path.startswith("tests/") or name.startswith("test_")
