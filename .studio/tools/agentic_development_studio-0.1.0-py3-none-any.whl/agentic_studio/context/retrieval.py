from __future__ import annotations

import re

from agentic_studio.contracts import (
    AuthorityTier,
    ContextHit,
    ContextQuery,
    FreshnessStatus,
    RetrievalProvider,
    SensitivityClass,
)

from .index import FileRecord, IndexSnapshot


class LexicalRetriever:
    def retrieve(self, query: ContextQuery, snapshot: IndexSnapshot) -> tuple[ContextHit, ...]:
        if RetrievalProvider.LEXICAL not in query.provider_policy:
            return ()
        if SensitivityClass.INTERNAL not in query.allowed_sensitivity:
            return ()
        terms = set(_tokens(" ".join((query.intent, *query.target_symbols))))
        ranked: list[tuple[float, float, str, FileRecord]] = []
        for record in snapshot.records:
            lexical = float(sum(_tokens(record.content.lower()).count(term) for term in terms))
            target = 4.0 if record.path in query.target_paths else 0.0
            if lexical == 0 and target == 0:
                continue
            ranked.append((target, lexical, record.path, record))
        ranked.sort(key=lambda item: (-item[0], -item[1], item[2]))
        hits: list[ContextHit] = []
        for index, (authority, lexical, _, raw_record) in enumerate(
            ranked[: query.result_limit], start=1
        ):
            record = raw_record
            hits.append(
                ContextHit(
                    schema_version="1.0.0",
                    hit_id=f"hit-{index}",
                    path=record.path,
                    symbol=query.target_symbols[0] if record.path in query.target_paths else None,
                    language=record.language,
                    line_start=1,
                    line_end=max(1, len(record.content.splitlines())),
                    content=record.content,
                    artifact_reference=None,
                    source_commit=query.source_revision,
                    working_tree_digest=snapshot.revision,
                    content_hash=record.content_hash,
                    index_revision=snapshot.revision,
                    provider="lexical",
                    retrieval_method="term_frequency",
                    authority_tier=(
                        AuthorityTier.AUTHORITATIVE if authority else AuthorityTier.SUPPORTING
                    ),
                    freshness=FreshnessStatus.CURRENT,
                    sensitivity=SensitivityClass.INTERNAL,
                    score_components={"authority": authority, "lexical": lexical},
                )
            )
        return tuple(hits)


def _tokens(value: str) -> list[str]:
    return re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", value.lower())
