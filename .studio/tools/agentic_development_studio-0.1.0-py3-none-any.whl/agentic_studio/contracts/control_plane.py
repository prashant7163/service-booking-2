from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from enum import StrEnum
from typing import Any, Literal, Self

from pydantic import Field, model_validator

from .planning import _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class RunPhase(StrEnum):
    DISCOVERY = "discovery"
    SPECIFICATION_APPROVED = "specification_approved"
    PLANNING = "planning"
    READINESS_PENDING = "readiness_pending"
    READY = "ready"
    RUNNING = "running"
    BLOCKED = "blocked"
    AWAITING_USER_APPROVAL = "awaiting_user_approval"
    APPROVED = "approved"
    CANCELLED = "cancelled"


class ArtifactKind(StrEnum):
    SPECIFICATION = "specification"
    APPROVAL = "approval"
    PLAN = "plan"
    READINESS = "readiness"
    TASK = "task"
    RESULT = "result"
    GATE = "gate"
    CHECKPOINT = "checkpoint"
    RESUME_MARKER = "resume_marker"
    DOCTOR_RESULT = "doctor_result"
    CONTROL = "control"
    CAPABILITY = "capability"
    INCIDENT = "incident"
    SUPPORTING_EVIDENCE = "supporting_evidence"


class GateKind(StrEnum):
    CODE_REVIEW = "code-review"
    DOCUMENTATION_REVIEW = "documentation-review"
    BUILD_VERIFICATION = "build-verification"
    QUALITY_REVIEW = "quality-review"
    INDEPENDENT_AUDIT = "independent-audit"
    MILESTONE_REVIEW = "milestone-review"


class ResultCode(StrEnum):
    OK = "ok"
    INVALID_INPUT = "invalid_input"
    NOT_INITIALIZED = "not_initialized"
    POLICY_DENIED = "policy_denied"
    STATE_CORRUPT = "state_corrupt"
    CONFLICT = "conflict"


RESULT_EXIT_CODES: Mapping[ResultCode, int] = {
    ResultCode.OK: 0,
    ResultCode.INVALID_INPUT: 2,
    ResultCode.NOT_INITIALIZED: 3,
    ResultCode.POLICY_DENIED: 4,
    ResultCode.STATE_CORRUPT: 5,
    ResultCode.CONFLICT: 6,
}


def _canonical_digest(payload: Mapping[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class ArtifactInput(_ImmutableStudioModel):
    kind: ArtifactKind
    file: str = Field(min_length=1, max_length=500)
    expected_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_file(self) -> Self:
        if not _is_safe_repo_locator(self.file):
            raise ValueError("artifact file must be repository-relative and non-escaping")
        return self


class _IdempotentRequest(_ImmutableStudioModel):
    idempotency_key: str = Field(min_length=1, max_length=200)

    def digest_payload(self) -> dict[str, Any]:
        return self.model_dump(
            mode="json",
            exclude={"idempotency_key"},
        )

    @property
    def payload_digest(self) -> str:
        return _canonical_digest(self.digest_payload())


class InitializeRun(_IdempotentRequest):
    run_id: StableId | None = None
    selected_runtime: str = Field(default="codex", min_length=1, max_length=120)


class ImportRun(_IdempotentRequest):
    file: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_file(self) -> Self:
        if not _is_safe_repo_locator(self.file):
            raise ValueError("import manifest file must be repository-relative and non-escaping")
        return self


class RunSelection(_IdempotentRequest):
    run_id: StableId


class ApproveRun(_IdempotentRequest):
    milestone_review_id: StableId
    milestone_review_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    decision: Literal["approved"]
    decided_by: str = Field(min_length=1, max_length=120)
    comment: str | None = Field(default=None, max_length=2000)


class ArtifactSubmission(_IdempotentRequest):
    kind: ArtifactKind
    file: str = Field(min_length=1, max_length=500)
    expected_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    gate_kind: GateKind | None = None

    @model_validator(mode="after")
    def validate_file(self) -> Self:
        if not _is_safe_repo_locator(self.file):
            raise ValueError("artifact file must be repository-relative and non-escaping")
        if self.kind is ArtifactKind.GATE and self.gate_kind is None:
            raise ValueError("gate submissions require an explicit gate kind")
        if self.kind is not ArtifactKind.GATE and self.gate_kind is not None:
            raise ValueError("gate kind is only valid for gate submissions")
        return self


def canonical_submission_digest(request: ArtifactSubmission) -> str:
    return _canonical_digest(request.digest_payload())


class RunImportManifest(_ImmutableContractModel):
    project_id: StableId
    run_id: StableId
    source: Literal["pre_native_import"]
    initial_phase: RunPhase
    selected_runtime: str = Field(min_length=1, max_length=120)
    current_source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    artifacts: list[ArtifactInput] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_import_evidence(self) -> Self:
        if any(artifact.expected_sha256 is None for artifact in self.artifacts):
            raise ValueError("import artifacts require an expected SHA-256 digest")
        locators = [artifact.file for artifact in self.artifacts]
        if len(locators) != len(set(locators)):
            raise ValueError("artifact paths must be unique repository-relative locators")
        if self.initial_phase is RunPhase.BLOCKED and not any(
            artifact.kind is ArtifactKind.READINESS for artifact in self.artifacts
        ):
            raise ValueError("blocked import requires failed readiness evidence")
        return self


class RegisteredArtifact(_ImmutableStudioModel):
    source_locator: str = Field(min_length=1, max_length=500)
    snapshot_locator: str = Field(min_length=1, max_length=500)
    kind: ArtifactKind
    subject_id: StableId | None = None
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_locators(self) -> Self:
        if not _is_safe_repo_locator(self.source_locator) or not _is_safe_repo_locator(
            self.snapshot_locator
        ):
            raise ValueError("artifact locators must be repository-relative and non-escaping")
        return self


class CommandResult(_ImmutableStudioModel):
    code: ResultCode
    summary: str = Field(min_length=1, max_length=500)
    state: dict[str, Any] | None = None
    next_action: str | None = Field(default=None, min_length=1, max_length=500)
    details: dict[str, Any] = Field(default_factory=dict)


class ControlPlaneError(Exception):
    def __init__(
        self,
        code: ResultCode,
        summary: str,
        *,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(summary)
        self.code = code
        self.summary = summary
        self.details = dict(details or {})

    def to_result(self) -> CommandResult:
        return CommandResult(code=self.code, summary=self.summary, details=self.details)
