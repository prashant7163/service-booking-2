from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from .planning import ArtifactReference, _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel
from .security import SensitivityClass


class AuthorityTier(StrEnum):
    AUTHORITATIVE = "authoritative"
    STRUCTURAL = "structural"
    SUPPORTING = "supporting"
    RECENT = "recent"


class FreshnessStatus(StrEnum):
    CURRENT = "current"
    STALE = "stale"
    UNKNOWN = "unknown"


class RetrievalProvider(StrEnum):
    STRUCTURAL = "structural"
    LEXICAL = "lexical"
    RECENT = "recent"


class ContextQuery(_ImmutableContractModel):
    query_id: StableId
    project_id: StableId
    run_id: StableId
    task_id: StableId
    agent_instance_id: StableId
    agent_envelope_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    role: str = Field(min_length=1, max_length=120)
    specialization_id: StableId | None
    intent: str = Field(min_length=1, max_length=500)
    target_paths: list[str]
    target_symbols: list[str]
    authority_requirements: list[AuthorityTier]
    source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    allowed_sensitivity: list[SensitivityClass] = Field(min_length=1)
    provider_policy: list[RetrievalProvider] = Field(min_length=1)
    result_limit: int = Field(ge=1, le=100)
    byte_budget: int = Field(ge=1, le=1_000_000)

    @model_validator(mode="after")
    def validate_scope(self) -> Self:
        if any(not _is_safe_repo_locator(path) for path in self.target_paths):
            raise ValueError("context target paths must be repository-relative")
        if len(self.target_paths) != len(set(self.target_paths)):
            raise ValueError("duplicate context target path")
        if len(self.provider_policy) != len(set(self.provider_policy)):
            raise ValueError("duplicate context provider")
        return self


class ContextHit(_ImmutableContractModel):
    hit_id: StableId
    path: str = Field(min_length=1, max_length=500)
    symbol: str | None = Field(default=None, max_length=500)
    language: str | None = Field(default=None, max_length=80)
    line_start: int | None = Field(default=None, ge=1)
    line_end: int | None = Field(default=None, ge=1)
    content: str | None
    artifact_reference: ArtifactReference | None
    source_commit: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    working_tree_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    content_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    index_revision: str = Field(pattern=r"^[0-9a-f]{64}$")
    provider: str = Field(min_length=1, max_length=120)
    retrieval_method: str = Field(min_length=1, max_length=120)
    authority_tier: AuthorityTier
    freshness: FreshnessStatus
    sensitivity: SensitivityClass
    score_components: dict[str, float]

    @model_validator(mode="after")
    def validate_provenance(self) -> Self:
        if not _is_safe_repo_locator(self.path):
            raise ValueError("context hit path must be repository-relative")
        if (self.content is None) == (self.artifact_reference is None):
            raise ValueError("context hit requires exactly one content source")
        if (self.line_start is None) != (self.line_end is None):
            raise ValueError("context line range must be complete")
        if self.line_start is not None and self.line_end is not None:
            if self.line_end < self.line_start:
                raise ValueError("context line range is reversed")
        return self


class ContextSnapshot(_ImmutableContractModel):
    snapshot_id: StableId
    project_id: StableId
    task_id: StableId
    source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    working_tree_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    index_revision: str = Field(pattern=r"^[0-9a-f]{64}$")
    authoritative_references: list[ArtifactReference]
    context_pack_manifest_reference: ArtifactReference


class ContextOmission(_ImmutableStudioModel):
    path: str = Field(min_length=1, max_length=500)
    reason: str = Field(min_length=1, max_length=120)


class ContextPackSection(_ImmutableStudioModel):
    hit_id: StableId
    path: str = Field(min_length=1, max_length=500)
    content: str
    content_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    authority_tier: AuthorityTier


class ContextPackManifest(_ImmutableContractModel):
    manifest_id: StableId
    query_id: StableId
    source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    index_revision: str = Field(pattern=r"^[0-9a-f]{64}$")
    providers_attempted: list[str]
    providers_used: list[str]
    included_sources: list[str]
    omitted_sources: list[ContextOmission]
    byte_budget: int = Field(ge=1)
    byte_count: int = Field(ge=0)
    redaction_count: int = Field(ge=0)
    outbound_destination: str
    policy_decision: str
    pack_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class ContextPack(_ImmutableContractModel):
    pack_id: StableId
    manifest: ContextPackManifest
    sections: list[ContextPackSection]

    @model_validator(mode="after")
    def validate_manifest(self) -> Self:
        if [section.path for section in self.sections] != list(self.manifest.included_sources):
            raise ValueError("context pack sections do not match manifest")
        total = sum(len(section.content.encode("utf-8")) for section in self.sections)
        if total != self.manifest.byte_count or total > self.manifest.byte_budget:
            raise ValueError("context pack byte accounting does not match manifest")
        return self
