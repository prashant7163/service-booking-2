from __future__ import annotations

from pydantic import Field

from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class QualityEngineeringRetention(_ImmutableStudioModel):
    max_complete_cycles: int = Field(default=10, ge=1)


class EvidenceRetention(_ImmutableStudioModel):
    quality_engineering_reports: QualityEngineeringRetention = Field(
        default_factory=QualityEngineeringRetention
    )


class StudioConfig(_ImmutableContractModel):
    project_id: StableId
    selected_runtime: str = Field(min_length=1, max_length=120)
    policy_profile_id: StableId = "default"
    evidence_retention: EvidenceRetention = Field(default_factory=EvidenceRetention)
