from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from .planning import _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel


class SensitivityClass(StrEnum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class SensitiveFinding(_ImmutableContractModel):
    finding_id: StableId
    path: str = Field(min_length=1, max_length=500)
    kind: str = Field(min_length=1, max_length=120)
    sensitivity: SensitivityClass
    confidence: str = Field(min_length=1, max_length=40)
    content_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    action: str = Field(min_length=1, max_length=120)

    @model_validator(mode="after")
    def validate_path(self) -> Self:
        if not _is_safe_repo_locator(self.path):
            raise ValueError("sensitive finding path must be repository-relative")
        return self


class OutboundManifest(_ImmutableContractModel):
    manifest_id: StableId
    destination: str = Field(min_length=1, max_length=200)
    source_paths: list[str]
    redaction_count: int = Field(ge=0)
    blocked_finding_ids: list[StableId]
    policy_decision: str = Field(min_length=1, max_length=120)
    payload_digest: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_policy_boundary(self) -> Self:
        if any(not _is_safe_repo_locator(path) for path in self.source_paths):
            raise ValueError("outbound source paths must be repository-relative")
        if self.blocked_finding_ids and self.policy_decision == "allowed":
            raise ValueError("outbound payload with blocking findings cannot be allowed")
        return self
