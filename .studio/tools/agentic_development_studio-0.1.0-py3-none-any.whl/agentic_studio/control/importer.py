from __future__ import annotations

import hashlib
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from pydantic import BaseModel, ValidationError

from agentic_studio.contracts import (
    ArtifactKind,
    MilestoneReadiness,
    ReadinessOutcome,
    RegisteredArtifact,
    RunImportManifest,
    RunPhase,
)
from agentic_studio.persistence import ArtifactRegistry


@dataclass(frozen=True, slots=True)
class PreparedImport:
    manifest: RunImportManifest
    manifest_digest: str
    artifacts: tuple[RegisteredArtifact, ...]
    readiness: RegisteredArtifact


class RunImporter:
    def __init__(self, project_root: Path, project_id: str) -> None:
        self.project_root = project_root.resolve(strict=True)
        self.project_id = project_id

    def _read_manifest(self, locator: str) -> bytes:
        candidate = self.project_root
        for component in PurePosixPath(locator).parts:
            candidate = candidate / component
            try:
                metadata = candidate.lstat()
            except FileNotFoundError as error:
                raise ValueError(f"import manifest does not exist: {locator}") from error
            if stat.S_ISLNK(metadata.st_mode):
                raise ValueError("import manifest path cannot contain symlinks")
        if not candidate.is_file():
            raise ValueError("import manifest must be a regular file")
        resolved = candidate.resolve(strict=True)
        try:
            resolved.relative_to(self.project_root)
        except ValueError as error:
            raise ValueError("import manifest must stay within the project") from error
        return resolved.read_bytes()

    def load_manifest(self, locator: str) -> tuple[RunImportManifest, str]:
        raw = self._read_manifest(locator)
        try:
            manifest = RunImportManifest.model_validate_json(raw)
        except (ValidationError, UnicodeError) as error:
            raise ValueError(f"invalid run import manifest: {error}") from error
        if manifest.project_id != self.project_id:
            raise ValueError("import manifest project ID does not match studio.yaml")
        digest = hashlib.sha256(manifest.canonical_json().encode("utf-8")).hexdigest()
        return manifest, digest

    @staticmethod
    def _validate_binding(model: BaseModel, *, project_id: str, run_id: str) -> None:
        model_project_id = getattr(model, "project_id", None)
        if isinstance(model_project_id, str) and model_project_id != project_id:
            raise ValueError("imported artifact project ID does not match manifest")
        model_run_id = getattr(model, "run_id", None)
        if isinstance(model_run_id, str) and model_run_id != run_id:
            raise ValueError("imported artifact run ID does not match manifest")
        identity = getattr(model, "identity", None)
        identity_project_id = getattr(identity, "project_id", None)
        if isinstance(identity_project_id, str) and identity_project_id != project_id:
            raise ValueError("imported specification project ID does not match manifest")

    def prepare(
        self,
        manifest: RunImportManifest,
        manifest_digest: str,
    ) -> PreparedImport:
        registry = ArtifactRegistry(self.project_root, manifest.run_id)
        registered: list[RegisteredArtifact] = []
        readiness_artifact: RegisteredArtifact | None = None
        for artifact_input in manifest.artifacts:
            artifact = registry.register(artifact_input)
            model = registry.load(artifact)
            self._validate_binding(
                model,
                project_id=manifest.project_id,
                run_id=manifest.run_id,
            )
            if artifact.kind is ArtifactKind.READINESS:
                readiness = MilestoneReadiness.model_validate(model)
                if readiness.outcome is not ReadinessOutcome.REVISION_REQUIRED:
                    raise ValueError("blocked import requires failed readiness evidence")
                readiness_artifact = artifact
            registered.append(artifact)
        if manifest.initial_phase is not RunPhase.BLOCKED or readiness_artifact is None:
            raise ValueError("pre-native import must begin blocked with failed readiness evidence")
        return PreparedImport(
            manifest=manifest,
            manifest_digest=manifest_digest,
            artifacts=tuple(registered),
            readiness=readiness_artifact,
        )
