from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import cast

from pydantic import BaseModel

from agentic_studio.contracts import (
    ArtifactKind,
    ArtifactReference,
    AssuranceOutcome,
    BuildStatus,
    CodeReview,
    GateKind,
    IndependentAudit,
    MilestoneDefinition,
    MilestonePlan,
    MilestoneReadiness,
    MilestoneReview,
    PlannedTask,
    ProjectSpecification,
    QualityEngineeringReport,
    ReadinessOutcome,
    RegisteredArtifact,
    ResultOutcome,
    ReviewOutcome,
    RunPhase,
    Task,
    TaskLifecycle,
    TaskResult,
)
from agentic_studio.persistence import ArtifactRegistry
from agentic_studio.progress import RunProjection

from .lifecycle import LifecycleController


class SubmissionDenied(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class SubmissionDecision:
    event_type: str
    summary: str
    milestone_id: str | None = None
    task_id: str | None = None
    attempt_number: int | None = None
    task_state: str | None = None


class SubmissionValidator:
    def __init__(self, registry: ArtifactRegistry, run: RunProjection) -> None:
        self.registry = registry
        self.run = run
        self.lifecycle = LifecycleController()

    def _accepted(self, kind: ArtifactKind) -> tuple[RegisteredArtifact, ...]:
        return tuple(artifact for artifact in self.run.artifacts if artifact.kind is kind)

    def _latest(self, kind: ArtifactKind) -> RegisteredArtifact:
        matches = self._accepted(kind)
        if not matches:
            raise SubmissionDenied(f"No accepted {kind.value} artifact is available.")
        return matches[-1]

    def _load_latest(self, kind: ArtifactKind) -> BaseModel:
        return self.registry.load(self._latest(kind))

    def _match_reference(self, reference: ArtifactReference) -> RegisteredArtifact:
        for artifact in self.run.artifacts:
            if (
                artifact.source_locator == reference.locator
                and artifact.sha256 == reference.sha256
                and (artifact.subject_id is None or artifact.subject_id == reference.artifact_id)
            ):
                return artifact
        raise SubmissionDenied(
            f"Artifact reference is not accepted by exact locator and digest: {reference.locator}"
        )

    def _validate_specification(self, model: BaseModel) -> SubmissionDecision:
        specification = cast(ProjectSpecification, model)
        if self.run.phase is not RunPhase.DISCOVERY:
            raise SubmissionDenied("Specification submission is not allowed in the current phase.")
        if specification.identity.project_id != self.run.project_id:
            raise SubmissionDenied("Specification project ID does not match the active run.")
        if specification.status.value != "approved" or specification.approval is None:
            raise SubmissionDenied("Specification requires exact human approval.")
        return SubmissionDecision(
            event_type="specification.approved",
            summary="Approved specification accepted.",
        )

    def _validate_plan(self, model: BaseModel) -> SubmissionDecision:
        plan = cast(MilestonePlan, model)
        if self.run.phase is not RunPhase.SPECIFICATION_APPROVED:
            raise SubmissionDenied("Plan submission requires an accepted approved specification.")
        accepted = self._latest(ArtifactKind.SPECIFICATION)
        specification = cast(ProjectSpecification, self.registry.load(accepted))
        embedded_specification = plan.project_specification
        if (
            embedded_specification is None
            or embedded_specification.canonical_json() != specification.canonical_json()
        ):
            raise SubmissionDenied("Plan embeds a different specification snapshot.")
        reference = plan.project_specification_reference
        if (
            reference.artifact_id != specification.identity.project_id
            or reference.locator != accepted.source_locator
            or reference.sha256 != specification.approval_digest()
        ):
            raise SubmissionDenied("Plan specification reference does not bind accepted evidence.")
        return SubmissionDecision(
            event_type="plan.approved",
            summary="Approved milestone plan accepted.",
        )

    @staticmethod
    def _readiness_references(readiness: MilestoneReadiness) -> tuple[ArtifactReference, ...]:
        evidence = (
            readiness.effective_standards,
            readiness.role_skill_independence,
            readiness.trusted_capability,
            readiness.threat_decision,
            readiness.doctor_result,
            readiness.integration_test_plan,
            readiness.rolling_progress,
        )
        return tuple(
            reference
            for item in evidence
            if item is not None
            for reference in item.evidence_references
        )

    def _validate_readiness(self, model: BaseModel) -> SubmissionDecision:
        readiness = cast(MilestoneReadiness, model)
        if self.run.phase not in {RunPhase.READINESS_PENDING, RunPhase.BLOCKED}:
            raise SubmissionDenied("Readiness submission is not allowed in the current phase.")
        if readiness.outcome is ReadinessOutcome.REVISION_REQUIRED:
            return SubmissionDecision(
                event_type="readiness.blocked",
                summary="Readiness evidence accepted with required revisions.",
                milestone_id=readiness.milestone_id,
            )
        if readiness.specification_reference is None or readiness.plan_reference is None:
            raise SubmissionDenied("Passing readiness requires specification and plan references.")
        if self.run.phase is RunPhase.BLOCKED and any(
            self.registry.load(artifact) == readiness
            for artifact in self._accepted(ArtifactKind.READINESS)
        ):
            raise SubmissionDenied(
                "Blocked readiness requires a distinct fresh readiness snapshot."
            )
        accepted_spec = self._latest(ArtifactKind.SPECIFICATION)
        accepted_plan = self._latest(ArtifactKind.PLAN)
        for reference, accepted, label in (
            (readiness.specification_reference, accepted_spec, "specification"),
            (readiness.plan_reference, accepted_plan, "plan"),
        ):
            if (
                reference.locator != accepted.source_locator
                or reference.sha256 != accepted.sha256
                or reference.artifact_id != accepted.subject_id
            ):
                raise SubmissionDenied(
                    f"Readiness {label} reference does not bind accepted evidence."
                )
        for reference in self._readiness_references(readiness):
            self._match_reference(reference)
        return SubmissionDecision(
            event_type="readiness.passed",
            summary="Fresh passing readiness evidence accepted.",
            milestone_id=readiness.milestone_id,
        )

    def _planned_task(self, task_id: str) -> tuple[MilestoneDefinition, PlannedTask]:
        plan = cast(MilestonePlan, self._load_latest(ArtifactKind.PLAN))
        for milestone in plan.milestones:
            for planned in milestone.tasks:
                if planned.task_id == task_id:
                    return milestone, planned
        raise SubmissionDenied(f"Task is not declared in the accepted plan: {task_id}")

    def _validate_task(self, model: BaseModel) -> SubmissionDecision:
        task = cast(Task, model)
        if self.run.phase not in {RunPhase.READY, RunPhase.RUNNING}:
            raise SubmissionDenied("Task submission requires passing readiness.")
        if task.project_id != self.run.project_id or task.run_id != self.run.run_id:
            raise SubmissionDenied("Task project or run ID does not match the active run.")
        milestone, planned = self._planned_task(task.task_id)
        authoritative_state = self.run.task_states.get(task.task_id)
        if authoritative_state not in {None, TaskLifecycle.READY.value}:
            raise SubmissionDenied(
                "Task must be explicitly scheduled for a fresh governed attempt before submission."
            )
        accepted_readiness = self._latest(ArtifactKind.READINESS)
        if (
            task.milestone_readiness.artifact_id != accepted_readiness.subject_id
            or task.milestone_readiness.locator != accepted_readiness.source_locator
            or task.milestone_readiness.sha256 != accepted_readiness.sha256
        ):
            raise SubmissionDenied("Task readiness reference does not bind the active snapshot.")
        readiness = cast(MilestoneReadiness, self.registry.load(accepted_readiness))
        owner = next(
            (
                instance
                for instance in readiness.approved_instances
                if instance.agent_instance_id == task.assigned_agent_instance_id
            ),
            None,
        )
        if owner is None or task.agent_envelope_digest != owner.approval_envelope_digest():
            raise SubmissionDenied("Task does not bind the approved agent envelope.")
        expected_attempt = (
            run_attempt if (run_attempt := self.run.active_attempt_number) is not None else 1
        )
        if (
            task.milestone_id != milestone.milestone_id
            or task.assigned_agent_instance_id != planned.owner_instance_id
            or task.author_id != planned.owner_instance_id
            or task.owning_role != planned.owner_role
            or task.workspace != planned.workspace.locator
            or set(task.dependency_ids) != set(planned.dependency_task_ids)
            or set(task.requirement_ids) != set(planned.requirement_ids)
            or task.attempt_number != expected_attempt
            or task.lifecycle is not TaskLifecycle.READY
        ):
            raise SubmissionDenied("Task owner, dependency, milestone, or attempt binding differs.")
        if any(
            self.run.task_states.get(dependency) != "complete" for dependency in task.dependency_ids
        ):
            raise SubmissionDenied("Task dependencies are not complete in authoritative state.")
        for reference in (
            task.milestone_readiness,
            task.contract_snapshot,
            task.work_package,
            task.milestone_progress,
            *task.change_intent_references,
            *task.declared_inputs,
        ):
            self._match_reference(reference)
        claimed = self.lifecycle.decide(TaskLifecycle.READY, TaskLifecycle.CLAIMED)
        running = self.lifecycle.decide(TaskLifecycle.CLAIMED, TaskLifecycle.RUNNING)
        if not claimed.allowed or not running.allowed:
            raise SubmissionDenied("Task cannot enter running state under lifecycle policy.")
        return SubmissionDecision(
            event_type="task.started",
            summary="Task accepted into the governed execution envelope.",
            milestone_id=task.milestone_id,
            task_id=task.task_id,
            attempt_number=task.attempt_number,
        )

    @staticmethod
    def _path_within(path: str, allowed: str) -> bool:
        candidate = PurePosixPath(path)
        boundary = PurePosixPath(allowed)
        return candidate == boundary or boundary in candidate.parents

    def _validate_result(self, model: BaseModel) -> SubmissionDecision:
        result = cast(TaskResult, model)
        if self.run.phase is not RunPhase.RUNNING:
            raise SubmissionDenied("Result submission requires a running task.")
        task_artifacts = self._accepted(ArtifactKind.TASK)
        task = next(
            (
                cast(Task, self.registry.load(artifact))
                for artifact in reversed(task_artifacts)
                if artifact.subject_id == result.task_id
            ),
            None,
        )
        if task is None:
            raise SubmissionDenied("Result does not reference an accepted task.")
        if self.run.task_states.get(result.task_id) != "running":
            raise SubmissionDenied("Result does not reference the active running task attempt.")
        if (
            result.attempt_number != task.attempt_number
            or result.change_class is not task.change_class
        ):
            raise SubmissionDenied("Result attempt or change class differs from the task envelope.")
        if any(
            not any(self._path_within(path, allowed) for allowed in task.allowed_paths)
            for path in result.changed_paths
        ):
            raise SubmissionDenied("Result changed paths exceed the task envelope.")
        for reference in (*result.artifact_references, *result.unit_test_evidence):
            self._match_reference(reference)
        requested = {
            ResultOutcome.SUCCESS: TaskLifecycle.IMPLEMENTATION_COMPLETE,
            ResultOutcome.FAILED: TaskLifecycle.FAILED,
            ResultOutcome.BLOCKED: TaskLifecycle.BLOCKED,
            ResultOutcome.INTERRUPTED: TaskLifecycle.INTERRUPTED,
        }[result.outcome]
        decision = self.lifecycle.decide(TaskLifecycle.RUNNING, requested)
        if not decision.allowed:
            raise SubmissionDenied("Result transition is denied by lifecycle policy.")
        event_type = {
            ResultOutcome.SUCCESS: "task.transition",
            ResultOutcome.FAILED: "task.failed",
            ResultOutcome.BLOCKED: "task.blocked",
            ResultOutcome.INTERRUPTED: "task.interrupted",
        }[result.outcome]
        return SubmissionDecision(
            event_type=event_type,
            summary="Task result accepted.",
            task_id=result.task_id,
            attempt_number=result.attempt_number,
            task_state=(
                TaskLifecycle.IMPLEMENTATION_COMPLETE.value
                if result.outcome is ResultOutcome.SUCCESS
                else None
            ),
        )

    def _active_task(self) -> Task:
        task_id = self.run.active_task_id
        if task_id is None:
            raise SubmissionDenied("Gate submission requires an active task.")
        for artifact in reversed(self._accepted(ArtifactKind.TASK)):
            if artifact.subject_id == task_id:
                return cast(Task, self.registry.load(artifact))
        raise SubmissionDenied("Active task evidence is unavailable.")

    def _successful_result(self, task: Task) -> TaskResult:
        for artifact in reversed(self._accepted(ArtifactKind.RESULT)):
            result = cast(TaskResult, self.registry.load(artifact))
            if result.task_id == task.task_id and result.attempt_number == task.attempt_number:
                if result.outcome is not ResultOutcome.SUCCESS or result.candidate_digest is None:
                    break
                return result
        raise SubmissionDenied("Gate does not bind an accepted successful result snapshot.")

    def _latest_code_review(self, task_id: str) -> CodeReview:
        for artifact in reversed(self._accepted(ArtifactKind.GATE)):
            candidate = self.registry.load(artifact)
            if isinstance(candidate, CodeReview) and candidate.task_id == task_id:
                return candidate
        raise SubmissionDenied("Independent audit requires accepted code review evidence.")

    def _validate_milestone_review(self, model: MilestoneReview) -> SubmissionDecision:
        if model.milestone_id != self.run.active_milestone_id:
            raise SubmissionDenied("Milestone review does not bind the active milestone.")
        plan = cast(MilestonePlan, self._load_latest(ArtifactKind.PLAN))
        milestone = next(
            (
                candidate
                for candidate in plan.milestones
                if candidate.milestone_id == model.milestone_id
            ),
            None,
        )
        if milestone is None:
            raise SubmissionDenied("Milestone review is not declared in the accepted plan.")
        planned_task_ids = {task.task_id for task in milestone.tasks}
        completed_task_ids = {
            task_id for task_id, state in self.run.task_states.items() if state == "complete"
        }
        if self.run.phase is not RunPhase.RUNNING or not planned_task_ids.issubset(
            completed_task_ids
        ):
            raise SubmissionDenied("Milestone review requires every planned task to be complete.")
        for reference in (
            model.readiness_reference,
            model.contract_reference,
            model.progress_reference,
            *model.code_review_references,
        ):
            self._match_reference(reference)
        if model.outcome != "ready_for_user":
            raise SubmissionDenied("Milestone review is not ready for user approval.")
        return SubmissionDecision(
            event_type="run.awaiting_user_approval",
            summary="Milestone review accepted for user approval.",
            milestone_id=model.milestone_id,
        )

    def _validate_gate(self, model: BaseModel, gate_kind: GateKind | None) -> SubmissionDecision:
        if gate_kind is None:
            raise SubmissionDenied("Gate submission requires an explicit gate kind.")
        expected_models: dict[GateKind, type[BaseModel]] = {
            GateKind.CODE_REVIEW: CodeReview,
            GateKind.DOCUMENTATION_REVIEW: CodeReview,
            GateKind.BUILD_VERIFICATION: BuildStatus,
            GateKind.QUALITY_REVIEW: QualityEngineeringReport,
            GateKind.INDEPENDENT_AUDIT: IndependentAudit,
            GateKind.MILESTONE_REVIEW: MilestoneReview,
        }
        if not isinstance(model, expected_models[gate_kind]):
            raise SubmissionDenied("Gate kind does not match the submitted artifact type.")
        if gate_kind is GateKind.MILESTONE_REVIEW:
            return self._validate_milestone_review(cast(MilestoneReview, model))

        task = self._active_task()
        result = self._successful_result(task)
        current_value = self.run.task_states.get(task.task_id)
        gate_states = {
            GateKind.CODE_REVIEW: TaskLifecycle.CODE_REVIEW,
            GateKind.DOCUMENTATION_REVIEW: TaskLifecycle.DOCUMENTATION_REVIEW,
            GateKind.BUILD_VERIFICATION: TaskLifecycle.BUILD_VERIFICATION,
            GateKind.QUALITY_REVIEW: TaskLifecycle.QUALITY_REVIEW,
            GateKind.INDEPENDENT_AUDIT: TaskLifecycle.INDEPENDENT_AUDIT,
        }
        chain = tuple(GateKind(item.replace("_", "-")) for item in task.gate_chain)
        if current_value == TaskLifecycle.IMPLEMENTATION_COMPLETE.value:
            chain_index = 0
        else:
            completed_gate = next(
                (kind for kind, state in gate_states.items() if state.value == current_value),
                None,
            )
            if completed_gate is None or completed_gate not in chain:
                raise SubmissionDenied("Gate is out of order for the authoritative task state.")
            chain_index = chain.index(completed_gate) + 1
        if chain_index >= len(chain):
            raise SubmissionDenied("Gate is out of order for the authoritative task state.")
        expected = chain[chain_index]
        if gate_kind is not expected:
            raise SubmissionDenied("Gate is out of order for the authoritative task state.")

        passed = False
        if isinstance(model, CodeReview):
            if (
                model.task_id != task.task_id
                or model.attempt_number != task.attempt_number
                or model.candidate_digest != result.candidate_digest
                or model.author_id != task.author_id
            ):
                raise SubmissionDenied("Code review does not bind the task result and author.")
            for reference in (*model.binding_references, *model.unit_test_references):
                self._match_reference(reference)
            for finding in model.findings:
                self._match_reference(finding.evidence_reference)
            passed = model.verdict is ReviewOutcome.PASS
            next_state = gate_states[gate_kind]
        elif isinstance(model, BuildStatus):
            if (
                model.repository_id != self.run.project_id
                or model.tested_snapshot_id != result.candidate_digest
            ):
                raise SubmissionDenied("Build status does not bind the active candidate.")
            if model.diagnostic_reference is not None:
                self._match_reference(model.diagnostic_reference)
            passed = model.outcome is ReviewOutcome.PASS
            next_state = TaskLifecycle.BUILD_VERIFICATION
        elif isinstance(model, QualityEngineeringReport):
            if (
                model.project_id != self.run.project_id
                or model.run_id != self.run.run_id
                or model.milestone_id != task.milestone_id
                or task.task_id not in model.task_ids
                or model.tested_snapshot_id != result.candidate_digest
            ):
                raise SubmissionDenied("Quality report does not bind the active task candidate.")
            for reference in (model.change_set_reference, model.graph_reference):
                self._match_reference(reference)
            for touchpoint in model.touchpoints:
                for reference in touchpoint.evidence:
                    self._match_reference(reference)
            for finding in model.findings:
                self._match_reference(finding.evidence_reference)
            passed = model.outcome is AssuranceOutcome.PASS
            next_state = TaskLifecycle.QUALITY_REVIEW
        elif isinstance(model, IndependentAudit):
            review = self._latest_code_review(task.task_id)
            if (
                model.milestone_id != task.milestone_id
                or model.candidate_digest != result.candidate_digest
                or task.author_id not in model.author_ids
                or review.reviewer_id not in model.reviewer_ids
            ):
                raise SubmissionDenied("Audit does not bind the task, review, and candidate.")
            for reference in model.traced_references:
                self._match_reference(reference)
            for finding in model.findings:
                self._match_reference(finding.evidence_reference)
            for disposition in model.dispositions:
                for reference in disposition.evidence:
                    self._match_reference(reference)
            passed = model.outcome is ReviewOutcome.PASS
            next_state = TaskLifecycle.INDEPENDENT_AUDIT
        else:
            raise SubmissionDenied("Unsupported gate artifact.")

        current = TaskLifecycle(cast(str, current_value))
        if not self.lifecycle.decide(current, next_state).allowed:
            raise SubmissionDenied("Gate transition is denied by lifecycle policy.")
        if passed:
            requested = next_state
        elif next_state is TaskLifecycle.INDEPENDENT_AUDIT:
            requested = TaskLifecycle.AUDIT_TRIAGE
        else:
            requested = TaskLifecycle.REVISION_REQUIRED
        if not passed and not self.lifecycle.decide(next_state, requested).allowed:
            raise SubmissionDenied("Gate remediation transition is denied by lifecycle policy.")
        if passed and chain_index == len(chain) - 1:
            return SubmissionDecision(
                event_type="task.completed",
                summary="Final required gate accepted; task completed.",
                milestone_id=task.milestone_id,
                task_id=task.task_id,
                attempt_number=task.attempt_number,
            )
        return SubmissionDecision(
            event_type="gate.submitted" if passed else "task.transition",
            summary="Gate evidence accepted.",
            milestone_id=task.milestone_id,
            task_id=task.task_id,
            attempt_number=task.attempt_number,
            task_state=requested.value,
        )

    def decide(
        self,
        kind: ArtifactKind,
        model: BaseModel,
        gate_kind: GateKind | None = None,
    ) -> SubmissionDecision:
        if kind is ArtifactKind.SPECIFICATION:
            return self._validate_specification(model)
        if kind is ArtifactKind.PLAN:
            return self._validate_plan(model)
        if kind is ArtifactKind.READINESS:
            return self._validate_readiness(model)
        if kind is ArtifactKind.TASK:
            return self._validate_task(model)
        if kind is ArtifactKind.RESULT:
            return self._validate_result(model)
        if kind is ArtifactKind.GATE:
            return self._validate_gate(model, gate_kind)
        if kind in {
            ArtifactKind.APPROVAL,
            ArtifactKind.DOCTOR_RESULT,
            ArtifactKind.SUPPORTING_EVIDENCE,
        }:
            return SubmissionDecision(
                event_type="artifact.registered",
                summary=f"{kind.value.replace('_', ' ').title()} accepted as supporting evidence.",
            )
        raise SubmissionDenied(f"Use the dedicated governed operation for {kind.value} artifacts.")
