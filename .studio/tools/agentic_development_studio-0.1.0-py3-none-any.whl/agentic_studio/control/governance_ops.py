from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from agentic_studio.contracts import (
    OperatorControl,
)
from agentic_studio.persistence import EventJournal
from agentic_studio.progress import RunProjection

from .operations import OperatorControlState


class GovernanceDenied(ValueError):
    pass


class RetentionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    reason: str = Field(min_length=1, max_length=500)
    dry_run: bool = False
    recoverable: bool = True


@dataclass(frozen=True, slots=True)
class RetentionPlan:
    candidates: tuple[str, ...]
    protected: tuple[str, ...]


class GovernanceOperations:
    def __init__(
        self,
        project_root: Path,
        journal: EventJournal,
        run: RunProjection,
    ) -> None:
        self.project_root = project_root
        self.journal = journal
        self.run = run

    def active_controls(self) -> tuple[OperatorControl, ...]:
        controls: dict[str, OperatorControl] = {}
        for event in self.journal.replay():
            if event.run_id != self.run.run_id:
                continue
            payload = event.model_dump(mode="json")["payload"]
            if event.event_type == "control.applied":
                control_payload = payload.get("control")
                if not isinstance(control_payload, dict):
                    raise GovernanceDenied("Control event is missing its typed control payload.")
                control = OperatorControl.model_validate(control_payload)
                controls[control.control_id] = control
            elif event.event_type == "control.cleared":
                control_id = payload.get("control_id")
                if isinstance(control_id, str):
                    controls.pop(control_id, None)
        if not controls:
            return ()
        state = OperatorControlState()
        for control in controls.values():
            state.apply(control)
        active = state.active
        remaining = sorted(
            (item for item in controls.values() if item.control_id != active.control_id),
            key=lambda item: item.control_id,
        )
        return (active, *remaining)

    def ensure_mutation_allowed(self) -> None:
        controls = self.active_controls()
        if controls:
            active = controls[0]
            raise GovernanceDenied(
                f"Mutation is blocked by active {active.action.value} control {active.control_id}."
            )

    def retention_plan(
        self,
        *,
        additional_protected: tuple[str, ...] = (),
    ) -> RetentionPlan:
        self.recover_unjournaled_tombstones()
        artifact_directory = self.project_root / ".studio" / "runs" / self.run.run_id / "artifacts"
        protected = {artifact.snapshot_locator for artifact in self.run.artifacts} | set(
            additional_protected
        )
        candidates: list[str] = []
        if artifact_directory.exists():
            for path in sorted(artifact_directory.iterdir()):
                if path.is_symlink():
                    raise GovernanceDenied("Retention refuses symbolic links.")
                if not path.is_file() or path.name.startswith("."):
                    continue
                locator = path.relative_to(self.project_root).as_posix()
                if locator not in protected:
                    candidates.append(locator)
        return RetentionPlan(tuple(candidates), tuple(sorted(protected)))

    def _tombstone_root(self) -> Path:
        return (
            self.project_root
            / ".studio"
            / "runs"
            / self.run.run_id
            / "evidence"
            / "retention-tombstones"
        )

    @staticmethod
    def _tombstone_name(transaction_id: str, locator: str) -> str:
        prefix = hashlib.sha256(f"{transaction_id}\0{locator}".encode()).hexdigest()[:16]
        return f"{prefix}-{Path(locator).name}"

    def tombstone_records(
        self,
        transaction_id: str,
        moved: tuple[str, ...],
    ) -> dict[str, str]:
        return {locator: self._tombstone_name(transaction_id, locator) for locator in moved}

    def recover_unjournaled_tombstones(self) -> tuple[str, ...]:
        tombstone_root = self._tombstone_root()
        if not tombstone_root.exists():
            return ()
        authorized_names: set[str] = set()
        for event in self.journal.replay():
            if (
                event.run_id != self.run.run_id
                or event.event_type != "retention.tombstone_recorded"
            ):
                continue
            payload = event.model_dump(mode="json")["payload"]
            tombstones = payload.get("tombstones")
            if isinstance(tombstones, dict):
                authorized_names.update(
                    name for name in tombstones.values() if isinstance(name, str)
                )
            else:
                deleted = payload.get("deleted", [])
                if isinstance(deleted, list):
                    authorized_names.update(
                        Path(locator).name for locator in deleted if isinstance(locator, str)
                    )
        restored: list[str] = []
        artifact_directory = self.project_root / ".studio" / "runs" / self.run.run_id / "artifacts"
        artifact_directory.mkdir(parents=True, exist_ok=True)
        for tombstone in sorted(tombstone_root.iterdir()):
            if tombstone.is_symlink() or not tombstone.is_file():
                raise GovernanceDenied("Retention tombstone is not a safe regular file.")
            if tombstone.name in authorized_names:
                continue
            original_name = tombstone.name.split("-", maxsplit=1)[-1]
            destination = artifact_directory / original_name
            locator = destination.relative_to(self.project_root).as_posix()
            if destination.exists() or destination.is_symlink():
                raise GovernanceDenied("Unjournaled retention tombstone cannot be restored safely.")
            os.replace(tombstone, destination)
            restored.append(locator)
        return tuple(restored)

    def apply_retention(
        self,
        request: RetentionRequest,
        plan: RetentionPlan,
        *,
        transaction_id: str,
    ) -> tuple[str, ...]:
        if request.dry_run:
            return ()
        if not request.recoverable:
            raise GovernanceDenied(
                "Irrecoverable retention is not supported by the journaled runtime."
            )
        moved: list[str] = []
        tombstone_root = self._tombstone_root()
        tombstone_root.mkdir(parents=True, exist_ok=True)
        try:
            for locator in plan.candidates:
                source = self.project_root / locator
                if source.is_symlink() or not source.is_file():
                    raise GovernanceDenied("Retention candidate changed during cleanup.")
                destination = tombstone_root / self._tombstone_name(transaction_id, locator)
                if destination.exists() or destination.is_symlink():
                    raise GovernanceDenied("Retention tombstone already exists.")
                os.replace(source, destination)
                moved.append(locator)
        except BaseException:
            self.rollback_retention(transaction_id, tuple(moved))
            raise
        return tuple(moved)

    def rollback_retention(self, transaction_id: str, moved: tuple[str, ...]) -> None:
        tombstone_root = self._tombstone_root()
        for locator in reversed(moved):
            source = tombstone_root / self._tombstone_name(transaction_id, locator)
            destination = self.project_root / locator
            if source.is_file() and not source.is_symlink() and not destination.exists():
                os.replace(source, destination)


def capability_transition_event(
    action: Literal["registered", "activated", "revoked", "quarantined"],
) -> str:
    return f"capability.{action}"
