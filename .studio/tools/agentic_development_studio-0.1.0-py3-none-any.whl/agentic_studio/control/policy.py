from __future__ import annotations

from types import MappingProxyType

from agentic_studio.contracts.workflow import TaskLifecycle

TASK_TRANSITIONS = MappingProxyType(
    {
        TaskLifecycle.PLANNED: frozenset({TaskLifecycle.READINESS_PENDING}),
        TaskLifecycle.READINESS_PENDING: frozenset(
            {TaskLifecycle.READY, TaskLifecycle.BLOCKED, TaskLifecycle.CANCELLED}
        ),
        TaskLifecycle.READY: frozenset({TaskLifecycle.CLAIMED}),
        TaskLifecycle.CLAIMED: frozenset(
            {TaskLifecycle.RUNNING, TaskLifecycle.INTERRUPTED, TaskLifecycle.CANCELLED}
        ),
        TaskLifecycle.RUNNING: frozenset(
            {
                TaskLifecycle.WAITING,
                TaskLifecycle.MATERIAL_DEVIATION,
                TaskLifecycle.BLOCKED,
                TaskLifecycle.IMPLEMENTATION_COMPLETE,
                TaskLifecycle.FAILED,
                TaskLifecycle.INTERRUPTED,
                TaskLifecycle.CANCELLED,
            }
        ),
        TaskLifecycle.WAITING: frozenset(
            {
                TaskLifecycle.RUNNING,
                TaskLifecycle.BLOCKED,
                TaskLifecycle.INTERRUPTED,
                TaskLifecycle.CANCELLED,
            }
        ),
        TaskLifecycle.MATERIAL_DEVIATION: frozenset(
            {TaskLifecycle.READY, TaskLifecycle.BLOCKED, TaskLifecycle.CANCELLED}
        ),
        TaskLifecycle.BLOCKED: frozenset({TaskLifecycle.READY, TaskLifecycle.CANCELLED}),
        TaskLifecycle.IMPLEMENTATION_COMPLETE: frozenset(
            {TaskLifecycle.CODE_REVIEW, TaskLifecycle.DOCUMENTATION_REVIEW}
        ),
        TaskLifecycle.CODE_REVIEW: frozenset(
            {
                TaskLifecycle.BUILD_VERIFICATION,
                TaskLifecycle.QUALITY_REVIEW,
                TaskLifecycle.REVISION_REQUIRED,
                TaskLifecycle.FAILED,
            }
        ),
        TaskLifecycle.BUILD_VERIFICATION: frozenset(
            {TaskLifecycle.QUALITY_REVIEW, TaskLifecycle.REVISION_REQUIRED, TaskLifecycle.FAILED}
        ),
        TaskLifecycle.QUALITY_REVIEW: frozenset(
            {
                TaskLifecycle.INDEPENDENT_AUDIT,
                TaskLifecycle.REVISION_REQUIRED,
                TaskLifecycle.FAILED,
            }
        ),
        TaskLifecycle.INDEPENDENT_AUDIT: frozenset(
            {TaskLifecycle.AUDIT_TRIAGE, TaskLifecycle.FAILED}
        ),
        TaskLifecycle.AUDIT_TRIAGE: frozenset(
            {
                TaskLifecycle.AWAITING_USER_APPROVAL,
                TaskLifecycle.REVISION_REQUIRED,
                TaskLifecycle.INDEPENDENT_AUDIT,
            }
        ),
        TaskLifecycle.DOCUMENTATION_REVIEW: frozenset(
            {
                TaskLifecycle.INDEPENDENT_AUDIT,
                TaskLifecycle.AWAITING_USER_APPROVAL,
                TaskLifecycle.REVISION_REQUIRED,
            }
        ),
        TaskLifecycle.AWAITING_USER_APPROVAL: frozenset(
            {TaskLifecycle.APPROVED, TaskLifecycle.REVISION_REQUIRED, TaskLifecycle.CANCELLED}
        ),
        TaskLifecycle.REVISION_REQUIRED: frozenset({TaskLifecycle.PLANNED}),
        TaskLifecycle.FAILED: frozenset({TaskLifecycle.READY, TaskLifecycle.CANCELLED}),
        TaskLifecycle.INTERRUPTED: frozenset(
            {TaskLifecycle.READY, TaskLifecycle.FAILED, TaskLifecycle.CANCELLED}
        ),
        TaskLifecycle.APPROVED: frozenset(),
        TaskLifecycle.CANCELLED: frozenset(),
    }
)

EVIDENCE_REQUIRED_RECOVERY = frozenset(
    {
        (TaskLifecycle.BLOCKED, TaskLifecycle.READY),
        (TaskLifecycle.MATERIAL_DEVIATION, TaskLifecycle.READY),
    }
)
