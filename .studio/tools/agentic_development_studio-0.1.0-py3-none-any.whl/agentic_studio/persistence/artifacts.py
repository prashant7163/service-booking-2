from __future__ import annotations

import errno
import hashlib
import json
import os
import re
import stat
from collections.abc import Iterator, Mapping
from contextlib import AbstractContextManager, contextmanager
from pathlib import Path, PurePosixPath
from types import MappingProxyType
from typing import Any

from pydantic import BaseModel, RootModel, TypeAdapter, ValidationError, model_validator

from agentic_studio.contracts import (
    Approval,
    ArtifactInput,
    ArtifactKind,
    BuildStatus,
    Checkpoint,
    CodeReview,
    ExternalCapability,
    IncidentRecord,
    IndependentAudit,
    MilestonePlan,
    MilestoneReadiness,
    MilestoneReview,
    OperatorControl,
    PreflightResult,
    ProjectSpecification,
    QualityEngineeringReport,
    RegisteredArtifact,
    ResumeMarker,
    Task,
    TaskResult,
)

from .atomic import atomic_write_bytes, atomic_write_text
from .locking import exclusive_file_lock

_SENSITIVE_KEY_FRAGMENTS = (
    "api_key",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "token",
)
_SAFE_RUN_ID = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")


class ArtifactCorruptionError(RuntimeError):
    pass


def _contains_sensitive_key(value: Any) -> bool:
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).lower().replace("-", "_")
            if any(fragment in normalized for fragment in _SENSITIVE_KEY_FRAGMENTS):
                return True
            if _contains_sensitive_key(item):
                return True
    elif isinstance(value, list):
        return any(_contains_sensitive_key(item) for item in value)
    return False


class GenericSupportingEvidence(RootModel[dict[str, Any]]):
    @model_validator(mode="after")
    def reject_secret_material(self) -> GenericSupportingEvidence:
        if _contains_sensitive_key(self.root):
            raise ValueError("generic supporting evidence cannot contain secret-like keys")
        return self


GateAdapter: TypeAdapter[Any] = TypeAdapter(
    CodeReview | BuildStatus | QualityEngineeringReport | IndependentAudit | MilestoneReview
)
ArtifactValidator = type[BaseModel] | TypeAdapter[Any]
ARTIFACT_MODELS: Mapping[ArtifactKind, ArtifactValidator] = MappingProxyType(
    {
        ArtifactKind.SPECIFICATION: ProjectSpecification,
        ArtifactKind.APPROVAL: Approval,
        ArtifactKind.PLAN: MilestonePlan,
        ArtifactKind.READINESS: MilestoneReadiness,
        ArtifactKind.TASK: Task,
        ArtifactKind.RESULT: TaskResult,
        ArtifactKind.GATE: GateAdapter,
        ArtifactKind.CHECKPOINT: Checkpoint,
        ArtifactKind.RESUME_MARKER: ResumeMarker,
        ArtifactKind.DOCTOR_RESULT: PreflightResult,
        ArtifactKind.CONTROL: OperatorControl,
        ArtifactKind.CAPABILITY: ExternalCapability,
        ArtifactKind.INCIDENT: IncidentRecord,
        ArtifactKind.SUPPORTING_EVIDENCE: GenericSupportingEvidence,
    }
)


def _canonical_json(model: BaseModel) -> str:
    payload = model.model_dump(mode="json", by_alias=True)
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def canonical_artifact_digest(model: BaseModel) -> str:
    return hashlib.sha256(_canonical_json(model).encode()).hexdigest()


def _subject_id(kind: ArtifactKind, model: BaseModel) -> str | None:
    if kind is ArtifactKind.SPECIFICATION:
        return ProjectSpecification.model_validate(model).identity.project_id
    field_names: Mapping[ArtifactKind, tuple[str, ...]] = {
        ArtifactKind.APPROVAL: ("subject_id",),
        ArtifactKind.PLAN: ("plan_id",),
        ArtifactKind.READINESS: ("readiness_id",),
        ArtifactKind.TASK: ("task_id",),
        ArtifactKind.RESULT: ("result_id",),
        ArtifactKind.GATE: ("review_id", "status_id", "report_id", "audit_id"),
        ArtifactKind.CHECKPOINT: ("checkpoint_id",),
        ArtifactKind.RESUME_MARKER: ("marker_id",),
        ArtifactKind.DOCTOR_RESULT: ("result_id",),
        ArtifactKind.CONTROL: ("control_id",),
        ArtifactKind.CAPABILITY: ("capability_id",),
        ArtifactKind.INCIDENT: ("incident_id",),
        ArtifactKind.SUPPORTING_EVIDENCE: (),
    }
    for field_name in field_names[kind]:
        value = getattr(model, field_name, None)
        if isinstance(value, str):
            return value
    return None


class ArtifactRegistry:
    def __init__(self, project_root: Path, run_id: str) -> None:
        if not _SAFE_RUN_ID.fullmatch(run_id):
            raise ValueError("run ID must be a stable identifier")
        self.project_root = project_root.resolve(strict=True)
        self.run_id = run_id
        self.run_directory = self.project_root / ".studio" / "runs" / run_id
        self.artifact_directory = self.run_directory / "artifacts"
        self.index_path = self.run_directory / "artifact-index.json"

    def _reject_symlink_components(self, locator: str) -> None:
        candidate = self.project_root
        for component in PurePosixPath(locator).parts:
            candidate = candidate / component
            try:
                metadata = candidate.lstat()
            except FileNotFoundError:
                return
            if stat.S_ISLNK(metadata.st_mode):
                raise ValueError(f"artifact path contains a symlink: {locator}")

    def _read_source(self, locator: str) -> bytes:
        self._reject_symlink_components(locator)
        components = PurePosixPath(locator).parts
        directory_fd = os.open(
            self.project_root,
            os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0),
        )
        descriptor = -1
        try:
            for component in components[:-1]:
                next_directory = os.open(
                    component,
                    os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0),
                    dir_fd=directory_fd,
                )
                os.close(directory_fd)
                directory_fd = next_directory
            descriptor = os.open(
                components[-1],
                os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0),
                dir_fd=directory_fd,
            )
            metadata = os.fstat(descriptor)
            if not stat.S_ISREG(metadata.st_mode):
                raise ValueError(f"artifact source must be a regular file: {locator}")
            with os.fdopen(descriptor, "rb") as stream:
                descriptor = -1
                return stream.read()
        except OSError as error:
            if error.errno in {errno.ELOOP, errno.ENOTDIR}:
                raise ValueError(f"artifact path contains a symlink: {locator}") from error
            if error.errno == errno.ENOENT:
                raise ValueError(f"artifact source does not exist: {locator}") from error
            raise
        finally:
            if descriptor != -1:
                os.close(descriptor)
            os.close(directory_fd)

    def _validate(self, artifact: ArtifactInput, raw: bytes) -> BaseModel:
        try:
            payload = json.loads(raw)
        except (UnicodeError, json.JSONDecodeError) as error:
            raise ValueError(f"{artifact.kind.value} artifact must contain valid JSON") from error
        validator = ARTIFACT_MODELS[artifact.kind]
        try:
            if isinstance(validator, TypeAdapter):
                validated = validator.validate_python(payload)
            else:
                validated = validator.model_validate(payload)
        except ValidationError as error:
            raise ValueError(
                f"{artifact.kind.value} artifact failed typed validation: {error}"
            ) from error
        if not isinstance(validated, BaseModel):
            raise TypeError("artifact validator returned an unsupported value")
        return validated

    def _ensure_artifact_directory(self) -> None:
        current = self.project_root
        for component in (".studio", "runs", self.run_id, "artifacts"):
            current = current / component
            try:
                metadata = current.lstat()
            except FileNotFoundError:
                try:
                    current.mkdir(mode=0o700)
                except FileExistsError:
                    metadata = current.lstat()
                else:
                    continue
            if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
                relative = current.relative_to(self.project_root)
                raise ArtifactCorruptionError(
                    f"artifact storage path is not a safe directory: {relative}"
                )

    def _writer_lock(self) -> AbstractContextManager[None]:
        self._ensure_artifact_directory()
        lock_path = self.run_directory / ".artifact-writer.lock"
        return exclusive_file_lock(lock_path, nofollow=True)

    def _load_index(self) -> list[dict[str, Any]]:
        if not self.index_path.exists():
            return []
        if self.index_path.is_symlink() or not self.index_path.is_file():
            raise ArtifactCorruptionError("artifact index is not a regular file")
        try:
            payload = json.loads(self.index_path.read_text(encoding="utf-8"))
            if not isinstance(payload, list):
                raise TypeError
            return [
                RegisteredArtifact.model_validate(item).model_dump(mode="json") for item in payload
            ]
        except (OSError, UnicodeError, json.JSONDecodeError, TypeError, ValidationError) as error:
            raise ArtifactCorruptionError("artifact index is corrupt") from error

    @contextmanager
    def rollback_registrations_on_error(self) -> Iterator[None]:
        self._ensure_artifact_directory()
        index_existed = self.index_path.exists() or self.index_path.is_symlink()
        index_before: bytes | None = None
        if index_existed:
            if self.index_path.is_symlink() or not self.index_path.is_file():
                raise ArtifactCorruptionError("artifact index is not a regular file")
            index_before = self.index_path.read_bytes()
        snapshots_before = (
            set(self.artifact_directory.glob("*.json"))
            if self.artifact_directory.exists()
            else set()
        )
        try:
            yield
        except BaseException:
            with self._writer_lock():
                snapshots_after = set(self.artifact_directory.glob("*.json"))
                for snapshot in snapshots_after - snapshots_before:
                    if snapshot.is_file() and not snapshot.is_symlink():
                        snapshot.unlink()
                if index_existed:
                    if index_before is None:
                        raise ArtifactCorruptionError(
                            "artifact index rollback state is invalid"
                        ) from None
                    atomic_write_bytes(self.index_path, index_before)
                elif self.index_path.exists() and not self.index_path.is_symlink():
                    self.index_path.unlink()
            raise

    def register(self, artifact: ArtifactInput) -> RegisteredArtifact:
        raw = self._read_source(artifact.file)
        validated = self._validate(artifact, raw)
        canonical = _canonical_json(validated).encode("utf-8")
        digest = hashlib.sha256(canonical).hexdigest()
        if artifact.expected_sha256 is not None and digest != artifact.expected_sha256:
            expected = artifact.expected_sha256
            raise ValueError(
                f"artifact digest mismatch for {artifact.file}: expected {expected}, got {digest}"
            )

        snapshot_locator = f".studio/runs/{self.run_id}/artifacts/{digest}.json"
        registered = RegisteredArtifact(
            source_locator=artifact.file,
            snapshot_locator=snapshot_locator,
            kind=artifact.kind,
            subject_id=_subject_id(artifact.kind, validated),
            sha256=digest,
        )
        snapshot = self.project_root / snapshot_locator
        with self._writer_lock():
            if snapshot.exists() or snapshot.is_symlink():
                if (
                    snapshot.is_symlink()
                    or not snapshot.is_file()
                    or snapshot.read_bytes() != canonical
                ):
                    raise ArtifactCorruptionError(
                        f"artifact snapshot digest collision at {snapshot_locator}"
                    )
            else:
                atomic_write_bytes(snapshot, canonical)

            index = self._load_index()
            serialized = registered.model_dump(mode="json")
            if serialized not in index:
                index.append(serialized)
                index.sort(
                    key=lambda item: (
                        str(item["source_locator"]),
                        str(item["kind"]),
                        str(item["sha256"]),
                    )
                )
                atomic_write_text(
                    self.index_path,
                    json.dumps(index, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                )
        return registered

    def load(self, registered: RegisteredArtifact) -> BaseModel:
        expected_prefix = f".studio/runs/{self.run_id}/artifacts/"
        if not registered.snapshot_locator.startswith(expected_prefix):
            raise ValueError("registered artifact belongs to another run")
        raw = self._read_source(registered.snapshot_locator)
        if hashlib.sha256(raw).hexdigest() != registered.sha256:
            raise ArtifactCorruptionError("registered artifact snapshot digest does not match")
        artifact = ArtifactInput(
            kind=registered.kind,
            file=registered.snapshot_locator,
            expected_sha256=registered.sha256,
        )
        return self._validate(artifact, raw)
