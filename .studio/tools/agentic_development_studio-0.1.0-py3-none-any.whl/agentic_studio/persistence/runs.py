from __future__ import annotations

from datetime import datetime
from pathlib import Path

from agentic_studio.contracts import RunSelection
from agentic_studio.progress.run_projection import ProjectionStore, RunProjection


class RunStore:
    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root.resolve(strict=True)
        self.projections = ProjectionStore(self.project_root)

    def list(self) -> tuple[RunProjection, ...]:
        projection = self.projections.load_or_rebuild()
        return tuple(projection.runs[run_id] for run_id in sorted(projection.runs))

    def inspect(self, run_id: str | None = None) -> RunProjection | None:
        projection = self.projections.load_or_rebuild()
        selected = run_id if run_id is not None else projection.active_run_id
        if selected is None:
            return None
        try:
            return projection.runs[selected]
        except KeyError as error:
            raise ValueError(f"unknown run: {selected}") from error

    def select(
        self,
        selection: RunSelection,
        *,
        project_id: str,
        occurred_at: datetime,
        event_id: str,
        trace_correlation_id: str,
        actor_role: str = "orchestrator-tech-lead",
        adapter_name: str = "codex",
    ) -> RunProjection:
        if self.inspect(selection.run_id) is None:
            raise ValueError(f"unknown run: {selection.run_id}")
        fields: dict[str, object] = {
            "schema_version": "1.0.0",
            "event_id": event_id,
            "occurred_at": occurred_at,
            "project_id": project_id,
            "run_id": selection.run_id,
            "session_id": None,
            "milestone_id": None,
            "task_id": None,
            "attempt_number": None,
            "agent_instance_id": None,
            "actor_role": actor_role,
            "event_type": "run.selected",
            "adapter_name": adapter_name,
            "trace_correlation_id": trace_correlation_id,
            "payload": {
                "operation": "run.select",
                "idempotency_key": selection.idempotency_key,
                "payload_digest": selection.payload_digest,
            },
        }
        self.projections.journal.record(**fields)
        selected = self.projections.rebuild().runs[selection.run_id]
        return selected
