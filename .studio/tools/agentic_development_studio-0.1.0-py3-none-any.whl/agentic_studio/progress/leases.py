from __future__ import annotations

from contextlib import AbstractContextManager
from datetime import datetime
from pathlib import Path

from agentic_studio.contracts import LeaseState, WorkerLease
from agentic_studio.persistence.atomic import atomic_write_text
from agentic_studio.persistence.locking import exclusive_file_lock


class LeaseConflictError(RuntimeError):
    pass


class LeaseStore:
    def __init__(self, project_root: Path) -> None:
        self.directory = project_root / ".studio" / "leases"
        self.lock_path = self.directory / ".writer.lock"

    def _lock(self) -> AbstractContextManager[None]:
        return exclusive_file_lock(self.lock_path)

    def _path(self, task_id: str) -> Path:
        return self.directory / f"{task_id}.json"

    def _read(self, task_id: str) -> WorkerLease | None:
        path = self._path(task_id)
        if not path.exists():
            return None
        return WorkerLease.model_validate_json(path.read_text(encoding="utf-8"))

    def claim(self, lease: WorkerLease, *, expected_generation: int) -> WorkerLease:
        with self._lock():
            current = self._read(lease.task_id)
            actual_generation = current.generation if current is not None else 0
            if actual_generation != expected_generation:
                raise LeaseConflictError(
                    "lease generation conflict: "
                    f"expected {expected_generation}, found {actual_generation}"
                )
            if lease.generation != expected_generation + 1:
                raise LeaseConflictError("new lease generation must increment exactly once")
            if current is not None and current.state is LeaseState.ACTIVE:
                raise LeaseConflictError(
                    "active lease must expire or be revoked before replacement"
                )
            atomic_write_text(self._path(lease.task_id), lease.model_dump_json(indent=2) + "\n")
            return lease

    def expire(self, now: datetime) -> tuple[WorkerLease, ...]:
        expired: list[WorkerLease] = []
        with self._lock():
            for path in sorted(self.directory.glob("*.json")):
                lease = WorkerLease.model_validate_json(path.read_text(encoding="utf-8"))
                if lease.state is LeaseState.ACTIVE and lease.heartbeat_deadline <= now:
                    lease = lease.model_copy(update={"state": LeaseState.EXPIRED})
                    atomic_write_text(path, lease.model_dump_json(indent=2) + "\n")
                    expired.append(lease)
        return tuple(expired)
