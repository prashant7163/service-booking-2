from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

from agentic_studio.persistence.atomic import atomic_write_bytes


class StateExportError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class StateExportManifest:
    files: tuple[str, ...]
    digests: tuple[tuple[str, str], ...] = ()


_SENSITIVE_FIELD = re.compile(
    rb'"(?:api[_-]?key|authorization|credential|password|private[_-]?key|secret|token)"\s*:',
    re.IGNORECASE,
)


def export_state(project_root: Path, destination: Path) -> StateExportManifest:
    state_root = project_root / ".studio"
    if state_root.is_symlink():
        raise StateExportError("state export refuses a symbolic-link state root")
    if not state_root.is_dir():
        raise StateExportError("project has no local Studio state")
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent))
    exported: list[str] = []
    digests: list[tuple[str, str]] = []
    try:
        for source in sorted(state_root.rglob("*")):
            relative = source.relative_to(project_root)
            if len(relative.parts) > 1 and relative.parts[1] in {"runtime", "tools"}:
                continue
            if source.is_symlink():
                raise StateExportError("state export refuses symbolic links")
            if not source.is_file():
                continue
            content = source.read_bytes()
            if _SENSITIVE_FIELD.search(content):
                raise StateExportError(f"sensitive field detected in {relative.as_posix()}")
            if str(project_root).encode("utf-8") in content:
                raise StateExportError(f"absolute project path detected in {relative.as_posix()}")
            atomic_write_bytes(staging / relative, content)
            exported.append(relative.as_posix())
            digests.append((relative.as_posix(), hashlib.sha256(content).hexdigest()))
        manifest_payload = {
            "schema_version": "1.0.0",
            "files": [{"locator": locator, "sha256": digest} for locator, digest in digests],
        }
        atomic_write_bytes(
            staging / "manifest.json",
            (json.dumps(manifest_payload, indent=2, sort_keys=True) + "\n").encode("utf-8"),
        )
        os.replace(staging, destination)
        return StateExportManifest(tuple(exported), tuple(digests))
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def export_review(
    project_root: Path,
    destination: Path,
    locators: list[str],
) -> StateExportManifest:
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent))
    exported: list[str] = []
    digests: list[tuple[str, str]] = []
    try:
        for locator in sorted(set(locators)):
            relative = Path(locator)
            if relative.is_absolute() or ".." in relative.parts:
                raise StateExportError("review export locator must be repository-relative")
            source = project_root / relative
            current = project_root
            for component in relative.parts:
                current /= component
                if current.is_symlink():
                    raise StateExportError("review export refuses symbolic links")
            if not source.is_file():
                raise StateExportError(f"review export source is missing: {locator}")
            content = source.read_bytes()
            if _SENSITIVE_FIELD.search(content):
                raise StateExportError(f"sensitive field detected in {locator}")
            if str(project_root).encode("utf-8") in content:
                raise StateExportError(f"absolute project path detected in {locator}")
            digest = hashlib.sha256(content).hexdigest()
            output_locator = Path("evidence") / digest / relative.name
            atomic_write_bytes(staging / output_locator, content)
            exported.append(output_locator.as_posix())
            digests.append((output_locator.as_posix(), digest))
        manifest_payload = {
            "schema_version": "1.0.0",
            "files": [{"locator": locator, "sha256": digest} for locator, digest in digests],
        }
        atomic_write_bytes(
            staging / "manifest.json",
            (json.dumps(manifest_payload, indent=2, sort_keys=True) + "\n").encode("utf-8"),
        )
        os.replace(staging, destination)
        return StateExportManifest(tuple(exported), tuple(digests))
    finally:
        shutil.rmtree(staging, ignore_errors=True)
