from __future__ import annotations

import hashlib
from datetime import UTC, datetime

from agentic_studio.contracts import (
    ArtifactReference,
    Checkpoint,
    ResumeMarker,
    ResumeSafety,
)

from .checkpoints import checkpoint_digest


def make_idempotency_key(
    project_id: str,
    run_id: str,
    task_id: str,
    attempt_number: int,
    action_id: str,
    payload_digest: str,
) -> str:
    raw = "\x1f".join((project_id, run_id, task_id, str(attempt_number), action_id, payload_digest))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class RecoveryClassifier:
    def classify(
        self,
        checkpoint: Checkpoint | None,
        *,
        derived_state_fresh: bool = True,
        side_effects_reconciled: bool = True,
    ) -> ResumeMarker:
        if (
            checkpoint is None
            or checkpoint.checkpoint_hash is None
            or checkpoint.checkpoint_hash != checkpoint_digest(checkpoint)
        ):
            return ResumeMarker(
                schema_version="1.0.0",
                marker_id="marker-invalid",
                checkpoint_reference=None,
                classification=ResumeSafety.INVALID,
                reason_code="checkpoint_missing_or_invalid",
                explanation="No validated durable checkpoint is available.",
                completed_work=[],
                remaining_work=["Restore or create a valid checkpoint."],
                next_operation="Stop recovery.",
                user_confirmation_required=True,
                created_at=datetime.now(UTC),
            )
        reference = ArtifactReference(
            artifact_id=checkpoint.checkpoint_id,
            locator=(
                f".studio/runs/{checkpoint.run_id}/checkpoints/"
                f"{checkpoint.journal_sequence:020d}-{checkpoint.checkpoint_id}.json"
            ),
            schema_version=checkpoint.schema_version,
            sha256=checkpoint.checkpoint_hash,
        )
        if not side_effects_reconciled:
            classification = ResumeSafety.CONDITIONAL
            reason = "side_effect_reconciliation_required"
            explanation = "An ambiguous side effect must be reconciled before resumption."
            next_operation = "Reconcile recorded idempotency outcome."
        elif not derived_state_fresh:
            classification = ResumeSafety.CONDITIONAL
            reason = "derived_state_rebuild_required"
            explanation = "Authoritative state is valid but a derived projection is stale."
            next_operation = "Rebuild derived state."
        else:
            classification = ResumeSafety.SAFE
            reason = "checkpoint_bindings_valid"
            explanation = "The durable checkpoint bindings validate."
            next_operation = checkpoint.next_operation
        return ResumeMarker(
            schema_version="1.0.0",
            marker_id=f"marker-{checkpoint.checkpoint_id}",
            checkpoint_reference=reference,
            classification=classification,
            reason_code=reason,
            explanation=explanation,
            completed_work=list(checkpoint.completed_work),
            remaining_work=list(checkpoint.pending_work),
            next_operation=next_operation,
            user_confirmation_required=classification is not ResumeSafety.SAFE,
            created_at=datetime.now(UTC),
        )
