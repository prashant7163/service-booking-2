from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from agentic_studio.contracts import Event, RegisteredArtifact, RunPhase
from agentic_studio.contracts.project_spec import StableId
from agentic_studio.persistence.atomic import atomic_write_text
from agentic_studio.persistence.journal import EventJournal, JournalCorruptionError


class _ProjectionModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class RunProjection(_ProjectionModel):
    project_id: StableId
    run_id: StableId
    phase: RunPhase
    provenance: Literal["native", "pre_native_import"]
    import_state: Literal["not_applicable", "started", "complete", "abandoned"]
    selected_runtime: str = Field(min_length=1, max_length=120)
    current_source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    active_milestone_id: StableId | None = None
    artifacts: list[RegisteredArtifact] = Field(default_factory=list)
    task_states: dict[StableId, str] = Field(default_factory=dict)
    retry_counters: dict[StableId, int] = Field(default_factory=dict)
    session_ids: list[StableId] = Field(default_factory=list)
    active_session_id: StableId | None = None
    active_task_id: StableId | None = None
    active_attempt_number: int | None = Field(default=None, ge=1)
    latest_checkpoint_id: StableId | None = None
    latest_resume_classification: str | None = None
    current_action: str | None = None
    next_action: str | None = None
    active_controls: dict[StableId, str] = Field(default_factory=dict)
    capability_states: dict[StableId, str] = Field(default_factory=dict)
    incident_states: dict[StableId, str] = Field(default_factory=dict)
    blockers: list[str] = Field(default_factory=list)
    last_event_sequence: int = Field(ge=1)


class ProjectProjection(_ProjectionModel):
    active_run_id: StableId | None
    runs: dict[StableId, RunProjection]
    last_event_sequence: int = Field(ge=0)


def _new_run(event: Event, payload: dict[str, Any], *, imported: bool) -> dict[str, Any]:
    phase_value = payload.get("phase", RunPhase.BLOCKED if imported else RunPhase.DISCOVERY)
    try:
        phase = RunPhase(phase_value)
    except (TypeError, ValueError) as error:
        raise JournalCorruptionError("run creation event contains an invalid phase") from error
    selected_runtime = payload.get("selected_runtime", event.adapter_name)
    source_revision = payload.get("current_source_revision")
    if not isinstance(selected_runtime, str) or not isinstance(source_revision, str):
        raise JournalCorruptionError("run creation event lacks runtime or source revision")
    return {
        "project_id": event.project_id,
        "run_id": event.run_id,
        "phase": phase,
        "provenance": "pre_native_import" if imported else "native",
        "import_state": "started" if imported else "not_applicable",
        "selected_runtime": selected_runtime,
        "current_source_revision": source_revision,
        "active_milestone_id": event.milestone_id,
        "artifacts": [],
        "task_states": {},
        "retry_counters": {},
        "session_ids": [],
        "active_session_id": None,
        "active_task_id": None,
        "active_attempt_number": None,
        "latest_checkpoint_id": None,
        "latest_resume_classification": None,
        "current_action": None,
        "next_action": None,
        "active_controls": {},
        "capability_states": {},
        "incident_states": {},
        "blockers": [],
        "last_event_sequence": event.sequence,
    }


def _require_run(runs: dict[str, dict[str, Any]], event: Event) -> dict[str, Any]:
    try:
        return runs[event.run_id]
    except KeyError as error:
        raise JournalCorruptionError(
            f"event {event.event_type} references unknown run {event.run_id}"
        ) from error


def _phase_from_payload(event: Event, payload: dict[str, Any], default: RunPhase) -> RunPhase:
    try:
        return RunPhase(payload.get("phase", default))
    except (TypeError, ValueError) as error:
        message = f"event {event.event_type} contains an invalid phase"
        raise JournalCorruptionError(message) from error


def reduce_project(events: Sequence[Event]) -> ProjectProjection:
    runs: dict[str, dict[str, Any]] = {}
    active_run_id: str | None = None
    project_id: str | None = None
    expected_sequence = 1

    for event in events:
        if event.sequence != expected_sequence:
            raise JournalCorruptionError("projection input sequence is not contiguous")
        expected_sequence += 1
        if project_id is None:
            project_id = event.project_id
        elif event.project_id != project_id:
            raise JournalCorruptionError("journal mixes project identities")
        payload = event.model_dump(mode="json")["payload"]

        if event.event_type == "run.initialized":
            if event.run_id in runs:
                raise JournalCorruptionError("run initialized more than once")
            runs[event.run_id] = _new_run(event, payload, imported=False)
            continue
        if event.event_type == "run.import.started":
            if event.run_id in runs:
                raise JournalCorruptionError("run import started more than once")
            runs[event.run_id] = _new_run(event, payload, imported=True)
            continue

        run = _require_run(runs, event)
        run["last_event_sequence"] = event.sequence
        if event.milestone_id is not None:
            run["active_milestone_id"] = event.milestone_id

        artifact_payload = payload.get("artifact")
        if artifact_payload is not None:
            try:
                artifact = RegisteredArtifact.model_validate(artifact_payload)
            except ValidationError as error:
                message = "artifact event contains invalid registration"
                raise JournalCorruptionError(message) from error
            if artifact not in run["artifacts"]:
                run["artifacts"].append(artifact)

        if event.event_type == "run.imported":
            if run["import_state"] != "started":
                raise JournalCorruptionError("run import completed without a start boundary")
            run["import_state"] = "complete"
            run["phase"] = _phase_from_payload(event, payload, RunPhase.BLOCKED)
        elif event.event_type == "run.import.abandoned":
            if run["import_state"] != "started":
                raise JournalCorruptionError("run import abandoned without a start boundary")
            run["import_state"] = "abandoned"
            run["phase"] = RunPhase.CANCELLED
        elif event.event_type == "run.selected":
            if run["import_state"] == "started":
                raise JournalCorruptionError("incomplete imported run cannot be selected")
            active_run_id = event.run_id
        elif event.event_type == "specification.approved":
            run["phase"] = RunPhase.SPECIFICATION_APPROVED
        elif event.event_type == "plan.approved":
            run["phase"] = RunPhase.READINESS_PENDING
        elif event.event_type == "readiness.blocked":
            run["phase"] = RunPhase.BLOCKED
            reason = payload.get("reason")
            if isinstance(reason, str) and reason not in run["blockers"]:
                run["blockers"].append(reason)
        elif event.event_type == "readiness.passed":
            run["phase"] = RunPhase.READY
            run["blockers"] = []
        elif event.event_type in {"run.started", "task.started"}:
            run["phase"] = RunPhase.RUNNING
            if event.task_id is not None:
                run["task_states"][event.task_id] = "running"
                run["active_task_id"] = event.task_id
                run["active_attempt_number"] = event.attempt_number
        elif event.event_type == "task.transition" and event.task_id is not None:
            state = payload.get("state")
            if not isinstance(state, str):
                raise JournalCorruptionError("task transition event requires a string state")
            run["task_states"][event.task_id] = state
        elif event.event_type == "task.completed" and event.task_id is not None:
            run["task_states"][event.task_id] = "complete"
        elif event.event_type == "gate.submitted" and event.task_id is not None:
            state = payload.get("state")
            if not isinstance(state, str):
                raise JournalCorruptionError("gate event requires a string task state")
            run["task_states"][event.task_id] = state
        elif (
            event.event_type in {"task.failed", "task.blocked", "task.interrupted"}
            and event.task_id is not None
        ):
            run["task_states"][event.task_id] = event.event_type.split(".", maxsplit=1)[1]
        elif event.event_type == "task.retry_scheduled" and event.task_id is not None:
            run["task_states"][event.task_id] = "ready"
            run["retry_counters"][event.task_id] = int(
                payload.get("retry_count", run["retry_counters"].get(event.task_id, 0) + 1)
            )
            run["active_task_id"] = event.task_id
            run["active_attempt_number"] = event.attempt_number
            run["phase"] = RunPhase.READY
        elif event.event_type == "checkpoint.created":
            checkpoint_id = payload.get("checkpoint_id")
            if isinstance(checkpoint_id, str):
                run["latest_checkpoint_id"] = checkpoint_id
            current_action = payload.get("current_action")
            next_action = payload.get("next_operation")
            if isinstance(current_action, str):
                run["current_action"] = current_action
            if isinstance(next_action, str):
                run["next_action"] = next_action
        elif event.event_type == "session.started":
            run["active_session_id"] = event.session_id
        elif event.event_type == "session.closed":
            if run["active_session_id"] == event.session_id:
                run["active_session_id"] = None
        elif event.event_type == "run.resumed":
            classification = payload.get("classification")
            if isinstance(classification, str):
                run["latest_resume_classification"] = classification
            current_action = payload.get("current_action")
            next_action = payload.get("next_operation")
            if isinstance(current_action, str):
                run["current_action"] = current_action
            if isinstance(next_action, str):
                run["next_action"] = next_action
        elif event.event_type == "control.applied":
            control = payload.get("control")
            if not isinstance(control, dict):
                raise JournalCorruptionError("control event requires typed control data")
            control_id = control.get("control_id")
            action = control.get("action")
            if not isinstance(control_id, str) or not isinstance(action, str):
                raise JournalCorruptionError("control event binding is invalid")
            run["active_controls"][control_id] = action
        elif event.event_type == "control.cleared":
            control_id = payload.get("control_id")
            if not isinstance(control_id, str):
                raise JournalCorruptionError("control clearance requires a control ID")
            run["active_controls"].pop(control_id, None)
        elif event.event_type.startswith("capability."):
            capability = payload.get("capability")
            if not isinstance(capability, dict):
                raise JournalCorruptionError("capability event requires typed capability data")
            capability_id = capability.get("capability_id")
            status = capability.get("status")
            if not isinstance(capability_id, str) or not isinstance(status, str):
                raise JournalCorruptionError("capability event binding is invalid")
            run["capability_states"][capability_id] = status
        elif event.event_type.startswith("incident."):
            incident = payload.get("incident")
            if not isinstance(incident, dict):
                raise JournalCorruptionError("incident event requires typed incident data")
            incident_id = incident.get("incident_id")
            status = incident.get("status")
            if not isinstance(incident_id, str) or not isinstance(status, str):
                raise JournalCorruptionError("incident event binding is invalid")
            run["incident_states"][incident_id] = status
        elif event.event_type == "run.awaiting_user_approval":
            run["phase"] = RunPhase.AWAITING_USER_APPROVAL
        elif event.event_type == "run.approved":
            run["phase"] = RunPhase.APPROVED
        elif event.event_type == "run.cancelled":
            run["phase"] = RunPhase.CANCELLED
            run["active_task_id"] = None
            run["active_attempt_number"] = None
            run["active_session_id"] = None

        if event.session_id is not None and event.session_id not in run["session_ids"]:
            run["session_ids"].append(event.session_id)

    projected_runs = {
        run_id: RunProjection.model_validate(payload) for run_id, payload in sorted(runs.items())
    }
    return ProjectProjection(
        active_run_id=active_run_id,
        runs=projected_runs,
        last_event_sequence=len(events),
    )


class ProjectionStore:
    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root.resolve(strict=True)
        self.journal = EventJournal(self.project_root / ".studio/journal/events.jsonl")
        self.projection_directory = self.project_root / ".studio/projection"
        self.project_status_path = self.projection_directory / "project-status.json"
        self.active_run_path = self.projection_directory / "active-run.json"

    def run_path(self, run_id: str) -> Path:
        return self.project_root / ".studio" / "runs" / run_id / "run.json"

    @staticmethod
    def _serialized(model: BaseModel) -> str:
        return json.dumps(model.model_dump(mode="json"), indent=2, sort_keys=True) + "\n"

    def _save(self, projection: ProjectProjection) -> None:
        atomic_write_text(self.project_status_path, self._serialized(projection))
        active_payload = {
            "run_id": projection.active_run_id,
            "last_event_sequence": projection.last_event_sequence,
        }
        atomic_write_text(
            self.active_run_path,
            json.dumps(active_payload, indent=2, sort_keys=True) + "\n",
        )
        for run in projection.runs.values():
            atomic_write_text(self.run_path(run.run_id), self._serialized(run))

    def rebuild(self) -> ProjectProjection:
        projection = reduce_project(self.journal.replay())
        self._save(projection)
        return projection

    @staticmethod
    def _quarantine(path: Path) -> None:
        if not path.exists() and not path.is_symlink():
            return
        try:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()[:12]
        except OSError:
            digest = "unreadable"
        target = path.with_name(f"{path.name}.corrupt-{digest}")
        suffix = 1
        while target.exists() or target.is_symlink():
            target = path.with_name(f"{path.name}.corrupt-{digest}-{suffix}")
            suffix += 1
        os.replace(path, target)

    def _load_current(self, journal_sequence: int) -> ProjectProjection | None:
        if not self.project_status_path.exists():
            return None
        try:
            projection = ProjectProjection.model_validate_json(
                self.project_status_path.read_text(encoding="utf-8")
            )
        except (OSError, UnicodeError, ValidationError):
            self._quarantine(self.project_status_path)
            return None
        if projection.last_event_sequence != journal_sequence:
            return None

        try:
            active = json.loads(self.active_run_path.read_text(encoding="utf-8"))
            if active != {
                "run_id": projection.active_run_id,
                "last_event_sequence": journal_sequence,
            }:
                raise ValueError
        except (OSError, UnicodeError, json.JSONDecodeError, ValueError):
            self._quarantine(self.active_run_path)
            return None

        for run in projection.runs.values():
            path = self.run_path(run.run_id)
            try:
                persisted = RunProjection.model_validate_json(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, ValidationError):
                self._quarantine(path)
                return None
            if persisted != run or persisted.last_event_sequence > journal_sequence:
                self._quarantine(path)
                return None
        return projection

    def load_or_rebuild(self) -> ProjectProjection:
        events = self.journal.replay()
        journal_sequence = events[-1].sequence if events else 0
        current = self._load_current(journal_sequence)
        if current is not None:
            return current
        projection = reduce_project(events)
        self._save(projection)
        return projection
