from __future__ import annotations

from pathlib import Path

from agentic_studio.contracts import Session
from agentic_studio.persistence.atomic import atomic_write_text


class SessionStore:
    def __init__(self, project_root: Path) -> None:
        self.directory = project_root / ".studio" / "sessions"

    def save(self, session: Session) -> Session:
        path = self.directory / f"{session.session_id}.json"
        if path.exists():
            raise FileExistsError(path)
        atomic_write_text(path, session.model_dump_json(indent=2) + "\n")
        return session

    def load(self, session_id: str) -> Session:
        return Session.model_validate_json(
            (self.directory / f"{session_id}.json").read_text(encoding="utf-8")
        )
